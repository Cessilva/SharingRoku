# SharingRoku
This is an example of how to share information between the main and scene files


https://community.roku.com/t5/Roku-Developer-Program/sending-info-from-scene-graph-to-main-thread/td-p/420474
